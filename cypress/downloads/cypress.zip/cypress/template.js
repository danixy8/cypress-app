/// <reference types="Cypress"/>

describe(" ", () => {

  it(" ", () => {
    cy.visit(" ")
  });

});